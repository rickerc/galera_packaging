//
// Copyright (C) 2010 Codership Oy <info@codership.com>
//

#include "gu_buffer.hpp"

