/*
 * Copyright (C) 2008 Codership Oy <info@codership.com>
 *
 * $Id: gu_uuid_test.h 495 2008-11-18 13:16:31Z alex $
 */

#ifndef __gu_uuid_test__
#define __gu_uuid_test__

extern Suite *gu_uuid_suite(void);

#endif /* __gu_uuid_test__ */
