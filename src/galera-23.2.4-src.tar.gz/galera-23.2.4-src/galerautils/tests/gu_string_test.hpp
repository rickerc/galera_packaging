// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_string_test__
#define __gu_string_test__

#include <check.h>

extern Suite* gu_string_suite(void);

#endif /* __gu_string_test__ */
