// Copyright (C) 2010 Codership Oy <info@codership.com>

// $Id: gu_utils_test.h 1869 2010-08-20 16:20:42Z alex $

#ifndef __gu_utils_test__
#define __gu_utils_test__

Suite *gu_utils_suite(void);

#endif /* __gu_utils_test__ */
