// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id: gu_mem_test.h 1036 2009-09-22 12:18:55Z alex $

#ifndef __gu_mem_test__
#define __gu_mem_test__

extern Suite *gu_mem_suite(void);

#endif /* __gu_mem_test__ */
