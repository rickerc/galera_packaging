// Copyright (C) 2008 Codership Oy <info@codership.com>

// $Id: gu_dbug_test.h 248 2008-03-23 16:32:00Z alex $

#ifndef __gu_dbug_test__
#define __gu_dbug_test__

Suite *gu_dbug_suite(void);

#endif /* __gu_dbug_test__ */
