/*
 * Copyright (C) 2008 Codership Oy <info@codership.com>
 *
 * $Id: gu_lock_step_test.h 2984 2013-03-05 10:38:09Z teemu $
 */

#ifndef __gu_lock_step_test__
#define __gu_lock_step_test__

extern Suite *gu_lock_step_suite(void);

#endif /* __gu_lock_step_test__ */
