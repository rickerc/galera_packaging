// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id: gu_uri_test.hpp 2984 2013-03-05 10:38:09Z teemu $

#ifndef __gu_uri_test__
#define __gu_uri_test__

#include <check.h>

extern Suite *gu_uri_suite(void);

#endif /* __gu_uri_test__ */
