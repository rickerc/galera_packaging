// Copyright (C) 2012 Codership Oy <info@codership.com>

// $Id: gu_mmh3_test.h 2794 2012-05-31 18:54:29Z alex $

#ifndef __gu_mmh3_test__
#define __gu_mmh3_test__

#include <check.h>

extern Suite *gu_mmh3_suite(void);

#endif /* __gu_mmh3_test__ */
