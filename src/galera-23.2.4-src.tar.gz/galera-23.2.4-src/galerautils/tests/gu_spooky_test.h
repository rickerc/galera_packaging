// Copyright (C) 2012 Codership Oy <info@codership.com>

// $Id: gu_spooky_test.h 2799 2012-06-02 06:48:38Z alex $

#ifndef __gu_spooky_test__
#define __gu_spooky_test__

#include <check.h>

extern Suite *gu_spooky_suite(void);

#endif /* __gu_spooky_test__ */
