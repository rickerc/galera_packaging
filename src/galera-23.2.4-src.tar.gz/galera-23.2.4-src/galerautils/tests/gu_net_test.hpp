// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id: gu_net_test.hpp 2984 2013-03-05 10:38:09Z teemu $

#ifndef __gu_net_test__
#define __gu_net_test__

#include <check.h>

extern Suite *gu_net_suite(void);

#endif /* __gu_net_test__ */
