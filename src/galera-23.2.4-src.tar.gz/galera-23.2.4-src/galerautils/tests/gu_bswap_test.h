// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id: gu_bswap_test.h 248 2008-03-23 16:32:00Z alex $

#ifndef __gu_bswap_test__
#define __gu_bswap_test__

Suite *gu_bswap_suite(void);

#endif /* __gu_bswap_test__ */
