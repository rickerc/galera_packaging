//
// Copyright (C) 2011 Codership Oy <info@codership.com>
//

#ifndef GU_VLQ_TEST_HPP
#define GU_VLQ_TEST_HPP

#include <check.h>

Suite* gu_vlq_suite();

#endif // GU_VLQ_TEST_HPP
