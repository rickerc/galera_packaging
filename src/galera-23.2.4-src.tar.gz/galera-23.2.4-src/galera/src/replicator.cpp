//
// Copyright (C) 2010 Codership Oy <info@codership.com>
//

#include "replicator.hpp"

namespace galera
{

const char* const
Replicator::TRIVIAL_SST(WSREP_STATE_TRANSFER_TRIVIAL);

} /* namespace galera */

